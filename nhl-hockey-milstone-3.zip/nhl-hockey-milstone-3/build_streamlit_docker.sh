echo $SYSTEM_PASSWD | sudo -S docker build -f Dockerfile.streamlit --tag streamlit-container:v1 .


