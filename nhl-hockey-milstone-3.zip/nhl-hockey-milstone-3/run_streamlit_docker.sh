echo $SYSTEM_PASSWD | sudo -S docker run -it -e COMET_API_KEY streamlit-container:v1


